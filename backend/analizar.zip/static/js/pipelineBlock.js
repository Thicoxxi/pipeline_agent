export function createPipelineBlock({ messages, provider }) {

  if (!messages || typeof messages.appendChild !== "function") {
    console.error("❌ messages inválido");
    return;
  }

  const wrap = document.createElement("div");
  wrap.className = "message assistant";

  // =========================
  // HEADER
  // =========================
  const header = document.createElement("div");
  header.className = "assistant-header";

  const providerBadge = document.createElement("div");
  providerBadge.className = "provider-badge";
  providerBadge.innerHTML = `🤖 ${provider || "auto"}`;

  const updateBtn = document.createElement("button");
  updateBtn.className = "update-btn";
  updateBtn.innerHTML = "♻️ Atualizar Pipeline";

  header.append(providerBadge, updateBtn);

  // =========================
  // SPLIT
  // =========================
  const split = document.createElement("div");
  split.className = "split-view";

  // =========================
  // GITLAB
  // =========================
  const gitlabPanel = document.createElement("div");
  gitlabPanel.className = "panel gitlab-panel";

  gitlabPanel.innerHTML = `
    <div class="panel-top">
      <div class="panel-title">🦊 GitLab CI</div>
    </div>
  `;

  const gitlabEditor = document.createElement("textarea");
  gitlabEditor.className = "editor";

  gitlabPanel.appendChild(gitlabEditor);

  // =========================
  // GITHUB
  // =========================
  const githubPanel = document.createElement("div");
  githubPanel.className = "panel github-panel";

  githubPanel.innerHTML = `
    <div class="panel-top">
      <div class="panel-title">🐙 GitHub Actions</div>
    </div>
  `;

  const githubEditor = document.createElement("textarea");
  githubEditor.className = "editor";

  githubPanel.appendChild(githubEditor);

  split.append(gitlabPanel, githubPanel);

  wrap.append(header, split);

  messages.appendChild(wrap);

  // =========================
  // API INTERNA (SEM DEPENDÊNCIA EXTERNA)
  // =========================
  function convertToGitHub(yaml) {
    try {
      if (!window.jsyaml) return "# js-yaml não carregado";

      const parsed = window.jsyaml.load(yaml);

      let jobs = "";

      for (const key in parsed) {

        const job = parsed[key];
        if (!job?.script) continue;

        const script = Array.isArray(job.script)
          ? job.script
          : [job.script];

        jobs += `
  ${key}:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run ${key}
        run: |
${script.map(s => `          ${s}`).join("\n")}
`;
      }

      return `name: CI

on:
  push:

jobs:
${jobs}`;

    } catch (err) {
      console.error("convertToGitHub error:", err);
      return "# erro ao converter YAML";
    }
  }

  // =========================
  // API EXPOSTA
  // =========================
  return {

    setProvider: (p) => {
      providerBadge.innerHTML = `🤖 ${p}`;
    },

    setGitlab: (yaml) => {
      if (!yaml) return;
      gitlabEditor.value = yaml;
    },

    setGithub: (yaml) => {
      if (!yaml) return;
      githubEditor.value = convertToGitHub(yaml);
    }
  };
}