export async function sendPrompt({
  prompt,
  provider,
  onProvider,
  onGitlab,
  onGithub,
  onError
}) {
  try {
    const res = await fetch("/api/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, provider })
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(text || "Erro ao conectar API");
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      // decode seguro (evita quebrar UTF-8 em chunks)
      buffer += decoder.decode(value, { stream: true });

      // SSE separa eventos por linha em branco
      const parts = buffer.split("\n\n");

      // último pedaço pode estar incompleto
      buffer = parts.pop() || "";

      for (const part of parts) {
        if (!part.startsWith("data:")) continue;

        const raw = part.replace("data: ", "").trim();
        if (!raw) continue;

        try {
          const json = JSON.parse(raw);

          // =========================
          // STREAM EVENTS
          // =========================
          if (json.provider && onProvider) {
            onProvider(json.provider);
          }

          if (json.gitlab && onGitlab) {
            onGitlab(json.gitlab);
          }

          if (json.github && onGithub) {
            onGithub(json.github);
          }

        } catch (err) {
          console.error("Erro ao parsear SSE:", err, part);

          if (onError) {
            onError(err);
          }
        }
      }
    }

  } catch (err) {
    console.error("Erro no sendPrompt:", err);

    if (onError) {
      onError(err);
    }
  }
}