import logging

from providers.llm.openai_provider import (
    OpenAIProvider
)

from providers.llm.groq_provider import (
    GroqProvider
)

logger = logging.getLogger(__name__)


# =========================================================
# STREAM LLM
# =========================================================
def stream_llm(
    prompt: str,
    provider: str = "auto"
):

    logger.info(
        f"[LLM] provider={provider}"
    )

    # =====================================================
    # AUTO
    # =====================================================
    if provider == "auto":

        provider_instance = (
            GroqProvider()
        )

    # =====================================================
    # GROQ
    # =====================================================
    elif provider == "groq":

        provider_instance = (
            GroqProvider()
        )

    # =====================================================
    # OPENAI
    # =====================================================
    elif provider == "openai":

        provider_instance = (
            OpenAIProvider()
        )

    else:

        provider_instance = (
            GroqProvider()
        )

    # =====================================================
    # STREAM
    # =====================================================
    full_response = ""

    for chunk in provider_instance.stream(
        prompt
    ):

        if not chunk:
            continue

        full_response += chunk

    # =====================================================
    # RETURN FINAL YAML
    # =====================================================
    yield {
        "provider": provider
    }

    yield {
        "yaml": full_response
    }