import os

from flask import (
    Flask,
    render_template
)

from core.config import Config
from core.logger import setup_logger

from api.routes.stream_routes import (
    stream_bp
)

from api.routes.github_routes import (
    github_bp
)

from api.routes.gitlab_routes import (
    gitlab_bp
)

# =========================================================
# LOGGER
# =========================================================
logger = setup_logger()

# =========================================================
# APP
# =========================================================
BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

app = Flask(
    __name__,

    template_folder=os.path.join(
        BASE_DIR,
        "templates"
    ),

    static_folder=os.path.join(
        BASE_DIR,
        "static"
    )
)

# =========================================================
# BLUEPRINTS
# =========================================================
app.register_blueprint(
    stream_bp
)

app.register_blueprint(
    github_bp
)

app.register_blueprint(
    gitlab_bp
)

# =========================================================
# HOME
# =========================================================
@app.route("/")
def home():

    return render_template(
        "index.html"
    )

# =========================================================
# START
# =========================================================
if __name__ == "__main__":

    try:

        Config.validate()

    except Exception as e:

        logger.error(
            str(e)
        )

    logger.info(
        f"[START] Providers: "
        f"{Config.summary()}"
    )

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )