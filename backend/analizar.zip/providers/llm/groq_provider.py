import logging

from groq import Groq

from core.config import Config

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """
Você é um especialista DevOps.

Retorne APENAS YAML válido.

Sem markdown.
Sem explicações.
Sem ```yaml
"""


class GroqProvider:

    def __init__(self):

        self.client = Groq(
            api_key=Config.GROQ_API_KEY
        )

    # =====================================================
    # STREAM
    # =====================================================
    def stream(
        self,
        prompt: str
    ):

        logger.info(
            "[GROQ] iniciando stream"
        )

        completion = self.client.chat.completions.create(

            model="llama-3.3-70b-versatile",

            temperature=0.2,

            stream=True,

            messages=[

                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                },

                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        for chunk in completion:

            try:

                delta = (
                    chunk
                    .choices[0]
                    .delta
                    .content
                )

                if delta:

                    yield delta

            except Exception:

                continue