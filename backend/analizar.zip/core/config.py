import os

from dotenv import load_dotenv

# =====================================================
# LOAD ENV ABSOLUTO
# =====================================================
BASE_DIR = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        ".."
    )
)

ENV_PATH = os.path.join(
    BASE_DIR,
    ".env"
)

print("ENV PATH =", ENV_PATH)

load_dotenv(
    dotenv_path=ENV_PATH,
    override=True
)


class Config:

    OPENAI_API_KEY = os.getenv(
        "OPENAI_API_KEY"
    )

    GROQ_API_KEY = os.getenv(
        "GROQ_API_KEY"
    )

    GITLAB_TOKEN = os.getenv(
        "GITLAB_TOKEN"
    )

    GITHUB_TOKEN = os.getenv(
        "GITHUB_TOKEN"
    )

    GITLAB_URL = os.getenv(
        "GITLAB_URL",
        "https://gitlab.com/api/v4"
    )

    GITHUB_API_URL = (
        "https://api.github.com"
    )

    @staticmethod
    def validate():

        if not (
            Config.OPENAI_API_KEY
            or Config.GROQ_API_KEY
        ):

            raise Exception(
                "Nenhum provider configurado"
            )

    @staticmethod
    def summary():

        return {

            "openai":
                "OK"
                if Config.OPENAI_API_KEY
                else "MISSING",

            "groq":
                "OK"
                if Config.GROQ_API_KEY
                else "MISSING",

            "gitlab":
                "OK"
                if Config.GITLAB_TOKEN
                else "MISSING",

            "github":
                "OK"
                if Config.GITHUB_TOKEN
                else "MISSING"
        }