import json
import logging

from llm_agent import stream_llm

logger = logging.getLogger(__name__)


class StreamService:

    # =====================================================
    # GENERATE STREAM
    # =====================================================
    @staticmethod
    def generate(
        prompt: str,
        provider: str = "auto"
    ):

        try:

            for chunk in stream_llm(
                prompt,
                provider
            ):

                # =========================================
                # STRING
                # =========================================
                if isinstance(chunk, str):

                    data = {
                        "yaml": chunk
                    }

                    yield (
                        f"data: "
                        f"{json.dumps(data)}\n\n"
                    )

                # =========================================
                # DICT
                # =========================================
                elif isinstance(chunk, dict):

                    yield (
                        f"data: "
                        f"{json.dumps(chunk)}\n\n"
                    )

        except Exception as e:

            logger.exception(
                "[STREAM ERROR]"
            )

            error_data = {
                "error": str(e)
            }

            yield (
                f"data: "
                f"{json.dumps(error_data)}\n\n"
            )