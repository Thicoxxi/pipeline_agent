from flask import (
    Blueprint,
    request
)

from core.config import Config

from services.yaml_service import (
    YamlService
)

from providers.scm.gitlab_client import (
    create_or_update_pipeline
)

gitlab_bp = Blueprint(
    "gitlab",
    __name__
)

# =========================================================
# APPLY GITLAB
# =========================================================
@gitlab_bp.route(
    "/api/gitlab/apply",
    methods=["POST"]
)
def apply_gitlab_pipeline():

    data = request.get_json(
        force=True
    )

    project_id = data.get(
        "project_id"
    )

    branch = data.get(
        "branch",
        "main"
    )

    yaml_content = data.get(
        "yaml",
        ""
    )

    # =====================================================
    # CONFIG
    # =====================================================
    if not Config.has_gitlab():

        return {

            "success": False,

            "error": (
                "GITLAB_TOKEN nao configurado"
            )

        }, 500

    # =====================================================
    # VALIDATION
    # =====================================================
    valid, validation_msg = (
        YamlService.validate(
            yaml_content
        )
    )

    if not valid:

        return {

            "success": False,

            "error": validation_msg

        }, 400

    # =====================================================
    # APPLY
    # =====================================================
    response = create_or_update_pipeline(

        project_id=project_id,

        branch=branch,

        yaml_content=yaml_content
    )

    if response.ok:

        return {

            "success": True
        }

    return {

        "success": False,

        "error": response.text

    }, response.status_code